<?php
/**
 * Recent Post Shortcode
 * @package Shortcode
 *
 */

add_shortcode( 'pasar_posts', 'pasar_recent_posts_shortcode' );
function pasar_recent_posts_shortcode( $atts ) {
	extract( shortcode_atts( array(
		'title'			=> __( 'Recent Posts', 'tokopress' ),
		'title_position'=> 'left',
		'post_type' 	=> 'post',
		'numbers' 		=> '3',
		'orderby' 		=> 'date',
		'order' 		=> 'desc',
	), $atts ) );

	$args = array(
			'post_type'				=> $post_type,
			'posts_per_page'		=> (int)($numbers),
			'orderby'				=> $orderby,
			'order'					=> $order,
			'ignore_sticky_posts'	=> 1
		);
	$query = new WP_Query( $args );
	?>

	<?php ob_start(); ?>

	<?php if( $query->have_posts() ) : ?>

	<section class="tpvc-posts-grid <?php if ( $title && $title_position != 'hide' ) echo 'title-'.$title_position; ?>">
		
		<?php if( "hide" != $title_position ) : ?>
			<h3 class="tpvc-section-title"><?php echo ( $title ) ? $title : __( 'Recent Posts', 'tokopress' ); ?></h3>
		<?php endif; ?>

		<div class="tpvc-post-row row">

		<?php $i = 0; ?>
		<?php while ( $query->have_posts() ) : ?>
			<?php $query->the_post(); ?>
			<?php $i++; ?>

			<div class="tpvc-post col-sm-6 col-md-4">
				<div class="tpvc-post-image">
					<a href="<?php echo get_permalink(); ?>">
					<?php if( has_post_thumbnail( get_the_ID() ) ) : ?>
						<?php echo get_the_post_thumbnail( get_the_ID(), 'blog-thumbnail' ); ?>
					<?php else : ?>
						<img src="http://placehold.it/490x270" alt="<?php echo get_the_title(); ?>">
					<?php endif; ?>
					</a>
				</div>

				<div class="tpvc-post-detail">
					<h3 class="post-title"><a href="<?php echo get_permalink(); ?>"><?php the_title(); ?></a></h3>
					<span class="post-date"><?php echo get_the_date(); ?></span>
					<p><?php echo wp_trim_words( get_the_excerpt(), 21, '&hellip;' ); ?></p>
					<a href="<?php the_permalink(); ?>" rel="bookmark" class="more-link"><i class="ficon-arrow-right"></i></a>
				</div>
			</div>

			<?php if ( $i%3 == 0 ) : ?>
				<div class="clearfix visible-md-block visible-lg-block"></div>
			<?php endif; ?>
			<?php if ( $i%2 == 0 ) : ?>
				<div class="clearfix visible-sm-block"></div>
			<?php endif; ?>
				
		<?php endwhile; ?>
		<?php wp_reset_postdata(); ?>

		</div>

	</section>

	<?php endif; ?>

	<?php
	return ob_get_clean();

}

add_action( 'vc_before_init', 'pasar_vc_posts' );
function pasar_vc_posts() {

	$params = array(
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Title', 'tokopress' ),
				'param_name'	=> 'title',
			),
			array(
				'type'			=> 'dropdown',
				'heading'		=> __( 'Title Position', 'tokopress' ),
				'param_name'	=> 'title_position',
				'value'			=> array(
									__( 'Left', 'tokopress' )	=> 'left',
									__( 'Right', 'tokopress' )	=> 'right',
									__( 'Center', 'tokopress' )	=> 'center',
									__( 'Hide', 'tokopress' )	=> 'hide'
								),
				'std'			=> 'left'
			),
			array(
				'type'			=> 'posttypes',
				'heading'		=> __( 'Post Type', 'tokopress' ),
				'param_name'	=> 'post_type',
				'value'			=> 'post'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Number Of Posts', 'tokopress' ),
				'param_name'	=> 'numbers',
				'value'			=> '3'
			),
			array(
				'type'			=> 'dropdown',
				'heading'		=> __( 'Order By', 'tokopress' ),
				'param_name'	=> 'orderby',
				'value'			=> array(
									__( 'Date', 'tokopress' )			=> 'date',
									__( 'ID', 'tokopress' )				=> 'ID',
									__( 'Title', 'tokopress' )			=> 'title',
									__( 'Name', 'tokopress' )			=> 'name',
									__( 'Comment Count', 'tokopress' )	=> 'comment_count',
									__( 'Author', 'tokopress' )			=> 'author',
								)
			),
			array(
				'type'			=> 'dropdown',
				'heading'		=> __( 'Order', 'tokopress' ),
				'param_name'	=> 'order',
				'value'			=> array(
									__( 'Descending', 'tokopress' )	=> 'DESC',
									__( 'Ascending', 'tokopress' )	=> 'ASC',
								)
			)
		);

	vc_map( array(
	   'name'				=> __( 'Pasar - Posts', 'tokopress' ),
	   'base'				=> 'pasar_posts',
	   'class'				=> '',
	   'icon'				=> 'tokopress_icon',
	   'category'			=> 'Pasar',
	   'admin_enqueue_js' 	=> '',
	   'admin_enqueue_css' 	=> '',
	   'params'				=> $params,
	   )
	);
}