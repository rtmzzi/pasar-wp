<?php
/**
 * WooCommerce Shortcode
 *
 * @package Shortcode
 */

/**
 * Products Shortcode
 */
add_shortcode( 'pasar_wc_products_toprated', 'pasar_shortcode_wc_products_toprated' );
function pasar_shortcode_wc_products_toprated( $atts ) {

	if ( ! class_exists('woocommerce') )
		return;

	global $woocommerce_loop;

	extract( shortcode_atts( array(
		'title'				=> __( 'Top Rated Products', 'tokopress' ),
		'title_position'	=> 'left',
		'numbers' 			=> '8',
		'columns' 			=> '4',
		'orderby'  			=> 'title',
		'order'    			=> 'asc',
		'carousel'			=> 'yes'
	), $atts ) );

	$meta_query = WC()->query->get_meta_query();

	$args = array(
		'post_type'				=> 'product',
		'post_status'			=> 'publish',
		'ignore_sticky_posts' 	=> 1,
		'no_found_rows' 		=> 1,
		'posts_per_page' 		=> $numbers,
		'orderby'             	=> $orderby,
		'order'              	=> $order,
		'meta_query'          	=> $meta_query
	);

	if( "hide" == $title_position ) {
		$paginate = "false";
	} 
	else {
		$paginate = "true";
	}

	ob_start();

	add_filter( 'posts_clauses', 'pasar_shortcode_wc_products_toprated_orderby' );
	$products = new WP_Query( apply_filters( 'woocommerce_shortcode_products_query', $args, $atts ) );
	remove_filter( 'posts_clauses', 'pasar_shortcode_wc_products_toprated_orderby' );

	$woocommerce_loop['columns'] = $columns;
	$carousel_id = intval( rand( 1, 1000) );

	if ( $products->have_posts() ) : ?>

	<div class="tpvc-woocommerce woocommerce columns-<?php echo $columns; ?> <?php echo ( "yes" == $carousel ? 'tpvc-carousel' : 'tpvc-no-carousel' ); ?> <?php if ( $title && $title_position != 'hide' ) echo 'title-'.$title_position; ?> clearfix">

		<?php if( "hide" != $title_position ) : ?>
			<h3 class="tpvc-section-title"><?php echo ( $title ) ? $title : __( 'Top Rated Products', 'tokopress' ); ?></h3>
		<?php endif; ?>

		<ul class="products <?php echo ( "yes" == $carousel ) ? "owl-carousel" : ""; ?>" id="tpvc-carousel-<?php echo $carousel_id ?>">

			<?php while ( $products->have_posts() ) : $products->the_post(); ?>

				<?php wc_get_template_part( 'content', 'product' ); ?>

			<?php endwhile; ?>

		</ul>
		
		<?php if( "yes" == $carousel ) : ?>
			<?php wp_enqueue_script( 'tokopress-js-owlcarousel' ); ?>
			<?php $js_code = "$('#tpvc-carousel-{$carousel_id}').owlCarousel({responsive:{ 0:{items:1}, 461:{items:2}, 992:{items:{$columns}} },loop: true, nav :{$paginate}, navText : ['<i class=\"ficon-angle-left\"></i>','<i class=\"ficon-angle-right\"></i>'], lazyLoad : true, autoPlay : true, dots: false });"; ?>
			<?php wc_enqueue_js( $js_code ); ?>
		<?php endif; ?>

	</div>

	<?php endif;

	wp_reset_postdata();

	return ob_get_clean();
}

function pasar_shortcode_wc_products_toprated_orderby( $args ) {
	global $wpdb;

	$args['where'] .= " AND $wpdb->commentmeta.meta_key = 'rating' ";

	$args['join'] .= "
		LEFT JOIN $wpdb->comments ON($wpdb->posts.ID = $wpdb->comments.comment_post_ID)
		LEFT JOIN $wpdb->commentmeta ON($wpdb->comments.comment_ID = $wpdb->commentmeta.comment_id)
	";

	$args['orderby'] = "$wpdb->commentmeta.meta_value DESC";

	$args['groupby'] = "$wpdb->posts.ID";

	return $args;
}

add_action( 'vc_before_init', 'pasar_vc_woo_products_toprated' );
function pasar_vc_woo_products_toprated() {

	if ( ! class_exists('woocommerce') )
		return;

	$params = array(
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Title', 'tokopress' ),
				'param_name'	=> 'title',
				'value'			=> __( 'Top Rated Products', 'tokopress' ),
			),
			array(
				'type'			=> 'dropdown',
				'heading'		=> __( 'Title Position', 'tokopress' ),
				'param_name'	=> 'title_position',
				'value'			=> array(
									__( 'Left', 'tokopress' )	=> 'left',
									__( 'Right', 'tokopress' )	=> 'right',
									__( 'Center', 'tokopress' )	=> 'center',
									__( 'Hide', 'tokopress' )	=> 'hide',
								),
				'std'			=> 'left'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Numbers', 'tokopress' ),
				'description'	=> __( 'How many products to show', 'tokopress' ),
				'param_name'	=> 'numbers',
				'value'			=> "8",
			),
			array(
				'type'			=> 'dropdown',
				'heading'		=> __( 'Columns', 'tokopress' ),
				'description'	=> __( 'How many columns per row', 'tokopress' ),
				'param_name'	=> 'columns',
				'value'			=> array(
									__( '1 Column', 'tokopress' )	=> '1',
									__( '2 Columns', 'tokopress' )	=> '2',
									__( '3 Columns', 'tokopress' )	=> '3',
									__( '4 Columns', 'tokopress' )	=> '4',
									__( '5 Columns', 'tokopress' )	=> '5'
								),
				'std'			=> '4'
			),
			array(
				'type'			=> 'dropdown',
				'heading'		=> __( 'Order By', 'tokopress' ),
				'param_name'	=> 'orderby',
				'value'			=> array(
									__( 'Title', 'tokopress' )		=> 'title',
									__( 'Date', 'tokopress' )		=> 'date',
									__( 'Menu Order', 'tokopress' )	=> 'menu_order',
									__( 'Random', 'tokopress' )		=> 'rand',
									__( 'ID', 'tokopress' )			=> 'id',
								),
				'std'			=> 'title'
			),
			array(
				'type'			=> 'dropdown',
				'heading'		=> __( 'Order', 'tokopress' ),
				'param_name'	=> 'order',
				'value'			=> array(
									__( 'Ascending', 'tokopress' )	=> 'ASC',
									__( 'Descending', 'tokopress' )	=> 'DESC',
								),
				'std'			=> 'ASC'
			),
			array(
				'type'			=> 'dropdown',
				'heading'		=> __( 'Carousel', 'tokopress' ),
				'param_name'	=> 'carousel',
				'value'			=> array(
									__( 'Yes', 'tokopress' )	=> 'yes',
									__( 'No', 'tokopress' )	=> 'no'
								),
				'std'			=> 'yes'
			),
		);

	vc_map( array(
	   'name'				=> __( 'Pasar - WooCommerce - Top Rated Products', 'tokopress' ),
	   'base'				=> 'pasar_wc_products_toprated',
	   'class'				=> '',
	   'icon'				=> 'woocommerce_icon',
	   'category'			=> 'Pasar',
	   'admin_enqueue_js' 	=> '',
	   'admin_enqueue_css' 	=> '',
	   'params'				=> $params,
	   )
	);
}