<?php
/**
 * Brand Shortcode
 * @package Shortcode
 *
 */

add_shortcode( 'pasar_brands', 'pasar_shortcode_brands' );
function pasar_shortcode_brands( $atts ) {
	extract( shortcode_atts( array(
		'title'	=> __( 'Popular Brands', 'tokopress' ),
		'title_position'=> 'left',
		'image_id_1'	=> '',
		'link_1'		=> '#',
		'image_id_2'	=> '',
		'link_2'		=> '#',
		'image_id_3'	=> '',
		'link_3'		=> '#',
		'image_id_4'	=> '',
		'link_4'		=> '#',
		'image_id_5'	=> '',
		'link_5'		=> '#',
		'image_id_6'	=> '',
		'link_6'		=> '#',
		'image_id_7'	=> '',
		'link_7'		=> '#',
		'image_id_8'	=> '',
		'link_8'		=> '#',
		'image_id_9'	=> '',
		'link_9'		=> '#',
		'image_id_10'	=> '',
		'link_10'		=> '#',
		'image_id_11'	=> '',
		'link_11'		=> '#',
		'image_id_12'	=> '',
		'link_12'		=> '#'
	), $atts ) );

	ob_start();

	wp_enqueue_script( 'tokopress-js-owlcarousel' );
	?>
	<div class="tpvc-brands-wrap <?php if ( $title && $title_position != 'hide' ) echo 'title-'.$title_position; ?>">

		<?php if( "hide" != $title_position ) : ?>
			<h3 class="tpvc-section-title"><?php echo ( $title ) ? $title : __( 'Popular Brands', 'tokopress' ); ?></h3>
		<?php endif; ?>
		
		<div class="tpvc-brands owl-carousel">
			
			<?php for( $i=1; $i<=12; $i++ ) : ?>
			<?php if( ${"image_id_".$i} ) : ?>
				<?php if( $image = wp_get_attachment_image( ${"image_id_".$i}, 'full' ) ) : ?>
					<div class="tpvc-brand">
						<a href="<?php echo ( ${"link_".$i} ) ? esc_url(${"link_".$i}) : "#"; ?>">
							<?php echo $image; ?>
						</a>
					</div>
				<?php endif; ?>
			<?php endif; ?>
			<?php endfor; ?>

		</div>
	</div>
	<?php

	return ob_get_clean();
}

add_action( 'vc_before_init', 'pasar_vc_brands' );
function pasar_vc_brands() {

	$params = array(
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Brand Title', 'tokopress' ),
				'param_name'	=> 'title',
			),
			array(
				'type'			=> 'dropdown',
				'heading'		=> __( 'Title Position', 'tokopress' ),
				'param_name'	=> 'title_position',
				'value'			=> array(
									__( 'Left', 'tokopress' )	=> 'left',
									__( 'Right', 'tokopress' )	=> 'right',
									__( 'Center', 'tokopress' )	=> 'center',
									__( 'Hide', 'tokopress' )	=> 'hide'
								),
				'std'			=> 'left'
			),
		);
	
	for( $i=1; $i <= 12; $i++ ) {
		$params[] = array(
				'type'			=> 'attach_image',
				'heading'		=> sprintf( __( 'Image #%s', 'tokopress' ), $i ),
				'param_name'	=> 'image_id_'.$i,
			);
		$params[] = array(
				'type'			=> 'textfield',
				'heading'		=> sprintf( __( 'Image URL #%s', 'tokopress' ), $i ),
				'param_name'	=> 'link_'.$i,
			);
	}

	vc_map( array(
	   'name'				=> __( 'Pasar - Brands', 'tokopress' ),
	   'base'				=> 'pasar_brands',
	   'class'				=> '',
	   'icon'				=> 'tokopress_icon',
	   'category'			=> 'Pasar',
	   'admin_enqueue_js' 	=> '',
	   'admin_enqueue_css' 	=> '',
	   'params'				=> $params,
	   )
	);
}