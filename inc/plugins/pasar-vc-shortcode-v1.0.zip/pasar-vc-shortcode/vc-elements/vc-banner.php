<?php
/**
 * Banner Shortcode
 * @package Shortcode
 *
 */

add_shortcode( 'pasar_banner', 'pasar_shortcode_banner' );
function pasar_shortcode_banner( $atts ) {
	extract( shortcode_atts( array(
		'image_id'	=> '',
		'title'		=> '',
		'desc'	=> '',
		'link'	=> '#',
	), $atts ) );

	ob_start();
	?>
	<div class="tpvc-banner-wrap">
		<div class="tpvc-banner">
			<a href="<?php echo ( $link ? esc_url( $link ) : '#' ); ?>">
				<figure>
					<?php echo wp_get_attachment_image( $image_id, 'full' ); ?>
					<figcaption>
						<div class="tpvc-banner-detail">
								<?php if( $title ) : ?>
									<h3 class="tpvc-banner-title"><?php echo $title; ?></h3>
								<?php endif; ?>

								<?php if( $desc ) : ?>
									<p class="tpvc-banner-desc"><?php echo $desc; ?></p>
								<?php endif; ?>
								
								<i class="tpvc-banner-icon ficon-arrow-right"></i>
						</div>
					</figcaption>			
				</figure>
			</a>
		</div>
	</div>
	<?php
	return ob_get_clean();
}

add_action( 'vc_before_init', 'pasar_vc_banner' );
function pasar_vc_banner() {
	
		$params[] = array(
				'type'			=> 'attach_image',
				'heading'		=> __( 'Image', 'tokopress' ),
				'param_name'	=> 'image_id',
			);
		$params[] = array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Title', 'tokopress' ),
				'param_name'	=> 'title',
			);
		$params[] = array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Description', 'tokopress' ),
				'param_name'	=> 'desc',
			);
		$params[] = array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Link URL', 'tokopress' ),
				'param_name'	=> 'link',
			);

	vc_map( array(
	   'name'				=> __( 'Pasar - Banner', 'tokopress' ),
	   'base'				=> 'pasar_banner',
	   'class'				=> '',
	   'icon'				=> 'tokopress_icon',
	   'category'			=> 'Pasar',
	   'admin_enqueue_js' 	=> '',
	   'admin_enqueue_css' 	=> PASAR_VC_CSS_URI,
	   'params'				=> $params,
	   )
	);
}