<?php
/**
 * Promotion Shortcode
 * @package Shortcode
 *
 */

add_shortcode( 'pasar_promotions', 'pasar_shortcode_promotions' );
function pasar_shortcode_promotions( $atts ) {
	extract( shortcode_atts( array(
		'title'				=> __( 'Special Promotions', 'tokopress' ),
		'title_position'	=> 'left',
		'promo_image_1'		=> '',
		'promo_title_1'		=> '',
		'promo_desc_1'		=> '',
		'promo_btn_text_1'	=> '',
		'promo_btn_url_1'	=> '#',
		'promo_image_2'		=> '',
		'promo_title_2'		=> '',
		'promo_desc_2'		=> '',
		'promo_btn_text_2'	=> '',
		'promo_btn_url_2'	=> '#',
		'promo_image_3'		=> '',
		'promo_title_3'		=> '',
		'promo_desc_3'		=> '',
		'promo_btn_text_3'	=> '',
		'promo_btn_url_3'	=> '#',
		'promo_image_4'		=> '',
		'promo_title_4'		=> '',
		'promo_desc_4'		=> '',
		'promo_btn_text_4'	=> '',
		'promo_btn_url_4'	=> '#',
	), $atts ) );

	ob_start();
	?>
	<div class="tpvc-promotions-wrap <?php if ( $title && $title_position != 'hide' ) echo 'title-'.$title_position; ?>">

		<?php if( "hide" != $title_position ) : ?>
			<h3 class="tpvc-section-title"><?php echo ( $title ) ? $title : __( 'Special Promotions', 'tokopress' ); ?></h3>
		<?php endif; ?>
		
		<div class="tpvc-promotions">
			<div class="tpvc-promotion-row row">
				<div class="tpvc-promotion-col col-md-8 col-xs-12">

					<div class="tpvc-promotion-row row">

						<div id="tpvc-promotion-1" class="tpvc-promotion tpvc-promotion-col col-md-12">
							<?php $image = wp_get_attachment_image_src( $promo_image_1, 'full' ); ?>
							<figure <?php if ( $image[0] ) echo 'style="background-image: url('.$image[0].');"'; ?> >
								<figcaption>
									<div class="tpvc-promotion-detail">
										<?php if( $promo_desc_1 ) : ?>
											<p class="tpvc-promotion-desc"><?php echo $promo_desc_1; ?></p>
										<?php endif; ?>
										<?php if( $promo_title_1 ) : ?>
											<h3 class="tpvc-promotion-title"><?php echo $promo_title_1; ?></h3>
										<?php endif; ?>
										<?php if( $promo_btn_text_1 ) : ?>
											<a class="tpvc-promotion-button" href="<?php echo ( $promo_btn_url_1 ) ? esc_url( $promo_btn_url_1 ) : '#'; ?>" ><?php echo $promo_btn_text_1; ?></a>
										<?php endif; ?>
									</div>
								</figcaption>			
							</figure>

						</div>

						<div class="tpvc-promotion-col col-md-12">

							<div class="tpvc-promotion-row row">

								<div id="tpvc-promotion-2" class="tpvc-promotion tpvc-promotion-col col-sm-6">
									<?php $image = wp_get_attachment_image_src( $promo_image_2, 'full' ); ?>
									<figure <?php if ( $image[0] ) echo 'style="background-image: url('.$image[0].');"'; ?> >
										<figcaption>
											<div class="tpvc-promotion-detail">
												<?php if( $promo_desc_2 ) : ?>
													<p class="tpvc-promotion-desc"><?php echo $promo_desc_2; ?></p>
												<?php endif; ?>
												<?php if( $promo_title_2 ) : ?>
													<h3 class="tpvc-promotion-title"><?php echo $promo_title_2; ?></h3>
												<?php endif; ?>
												<?php if( $promo_btn_text_2 ) : ?>
													<a class="tpvc-promotion-button" href="<?php echo ( $promo_btn_url_2 ) ? esc_url( $promo_btn_url_2 ) : '#'; ?>"><?php echo $promo_btn_text_2; ?></a>
												<?php endif; ?>
											</div>
										</figcaption>			
									</figure>
								</div>

								<div id="tpvc-promotion-3" class="tpvc-promotion tpvc-promotion-col col-sm-6">
									<?php $image = wp_get_attachment_image_src( $promo_image_3, 'full' ); ?>
									<figure <?php if ( $image[0] ) echo 'style="background-image: url('.$image[0].');"'; ?> >
										<figcaption>
											<div class="tpvc-promotion-detail">
												<?php if( $promo_desc_3 ) : ?>
													<p class="tpvc-promotion-desc"><?php echo $promo_desc_3; ?></p>
												<?php endif; ?>
												<?php if( $promo_title_3 ) : ?>
													<h3 class="tpvc-promotion-title"><?php echo $promo_title_3; ?></h3>
												<?php endif; ?>
												<?php if( $promo_btn_text_3 ) : ?>
													<a class="tpvc-promotion-button" href="<?php echo ( "" !== $promo_btn_url_3 ) ? esc_url( $promo_btn_url_3 ) : '#'; ?>"><?php echo $promo_btn_text_3; ?></a>
												<?php endif; ?>
											</div>
										</figcaption>			
									</figure>
								</div>

							</div>
						</div>
					</div>
				</div>

				<div id="tpvc-promotion-4" class="tpvc-promotion tpvc-promotion-col col-md-4 col-xs-12">
					<?php $image = wp_get_attachment_image_src( $promo_image_4, 'full' ); ?>
					<figure <?php if ( $image[0] ) echo 'style="background-image: url('.$image[0].');"'; ?> >
						<figcaption>
							<div class="tpvc-promotion-detail">
								<?php if( $promo_desc_4 ) : ?>
									<p class="tpvc-promotion-desc"><?php echo $promo_desc_4; ?></p>
								<?php endif; ?>
								<?php if( $promo_title_4 ) : ?>
									<h3 class="tpvc-promotion-title"><?php echo $promo_title_4; ?></h3>
								<?php endif; ?>
								<?php if( $promo_btn_text_4 ) : ?>
									<a class="tpvc-promotion-button" href="<?php echo ( $promo_btn_url_4 ) ? esc_url( $promo_btn_url_4 ) : '#'; ?>"><?php echo $promo_btn_text_4; ?></a>
								<?php endif; ?>
							</div>
						</figcaption>			
					</figure>
				</div>
			</div>

		</div>	
	</div>
	<?php
	return ob_get_clean();
}

add_action( 'vc_before_init', 'pasar_vc_promotions' );
function pasar_vc_promotions() {

	$params = array(
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Promotion Title', 'tokopress' ),
				'param_name'	=> 'title',
			),
			array(
				'type'			=> 'dropdown',
				'heading'		=> __( 'Title Position', 'tokopress' ),
				'param_name'	=> 'title_position',
				'value'			=> array(
									__( 'Hide', 'tokopress' )	=> 'hide',
									__( 'Left', 'tokopress' )	=> 'left',
									__( 'Right', 'tokopress' )	=> 'right',
									__( 'Center', 'tokopress' )	=> 'center',
								),
				'std'			=> 'hide'
			),
		);
	
	for( $i=1; $i <= 4; $i++ ) {
		$params[] = array(
				'type'			=> 'attach_image',
				'heading'		=> sprintf( __( 'Promotion #%s - Image', 'tokopress' ), $i ),
				'param_name'	=> 'promo_image_'.$i,
			);
		$params[] = array(
				'type'			=> 'textfield',
				'heading'		=> sprintf( __( 'Promotion #%s - Description', 'tokopress' ), $i ),
				'param_name'	=> 'promo_desc_'.$i,
			);
		$params[] = array(
				'type'			=> 'textfield',
				'heading'		=> sprintf( __( 'Promotion #%s - Title', 'tokopress' ), $i ),
				'param_name'	=> 'promo_title_'.$i,
			);
		$params[] = array(
				'type'			=> 'textfield',
				'heading'		=> sprintf( __( 'Promotion #%s - Button Text', 'tokopress' ), $i ),
				'param_name'	=> 'promo_btn_text_'.$i,
			);
		$params[] = array(
				'type'			=> 'textfield',
				'heading'		=> sprintf( __( 'Promotion #%s - Button URL', 'tokopress' ), $i ),
				'param_name'	=> 'promo_btn_url_'.$i,
			);
	}

	vc_map( array(
	   'name'				=> __( 'Pasar - Promotions', 'tokopress' ),
	   'base'				=> 'pasar_promotions',
	   'class'				=> '',
	   'icon'				=> 'tokopress_icon',
	   'category'			=> 'Pasar',
	   'admin_enqueue_js' 	=> '',
	   'admin_enqueue_css' 	=> '',
	   'params'				=> $params,
	   )
	);
}