<?php
/**
 * WooCommerce Shortcode
 *
 * @package Shortcode
 */

/**
 * Product Category
 */
add_shortcode( 'pasar_wc_categories', 'pasar_shortcode_product_categories' );
function pasar_shortcode_product_categories( $atts ){

	if ( ! class_exists('woocommerce') )
		return;

	global $woocommerce_loop;

	extract( shortcode_atts( array(
		'title'		 		=> __( 'Product Categories', 'tokopress' ),
		'title_position'	=> 'left',
		'numbers'     		=> 8,
		'columns' 	 		=> '4',
		'hide_empty' 		=> 1,
		'orderby'    		=> 'none',
		'order'     		=> 'ASC',
		'parent'     		=> '',
		'timePlay'	 		=> 'true',
		'carousel'			=> 'true'
	), $atts ) );

	if ( isset( $atts[ 'ids' ] ) ) {
		$ids = explode( ',', $atts[ 'ids' ] );
		$ids = array_map( 'trim', $ids );
	} else {
		$ids = array();
	}

	$hide_empty = ( $hide_empty == true || $hide_empty == 1 ) ? 1 : 0;

	// get terms and workaround WP bug with parents/pad counts
	$args = array(
		'orderby'    => $orderby,
		'order'      => $order,
		'hide_empty' => $hide_empty,
		'include'    => $ids,
		'pad_counts' => true,
		'child_of'   => $parent
	);

	$product_categories = get_terms( 'product_cat', $args );

	if ( $parent !== "" ) {
		$product_categories = wp_list_filter( $product_categories, array( 'parent' => $parent ) );
	}

	if ( $hide_empty ) {
		foreach ( $product_categories as $key => $category ) {
			if ( $category->count == 0 ) {
				unset( $product_categories[ $key ] );
			}
		}
	}

	if ( $numbers ) {
		$product_categories = array_slice( $product_categories, 0, $numbers );
	}

	$woocommerce_loop['columns'] = $columns;

	if( "hide" == $title_position ) {
		$paginate = "false";
	} 
	else {
		$paginate = "true";
	}

	ob_start();

	// Reset loop/columns globals when starting a new loop
	$woocommerce_loop['loop'] = $woocommerce_loop['column'] = '';
	$carousel_id = intval( rand( 1, 1000) );

	if ( $product_categories ) { ?>
	<div class="tpvc-woocommerce woocommerce columns-<?php echo $columns; ?> <?php echo ( "yes" == $carousel ? 'tpvc-carousel' : 'tpvc-no-carousel' ); ?> <?php if ( $title && $title_position != 'hide' ) echo 'title-'.$title_position; ?> clearfix">

		<?php if( "hide" != $title_position ) : ?>
			<h3 class="tpvc-section-title"><?php echo ( $title ) ? $title : __( 'Product Categories', 'tokopress' ); ?></h3>
		<?php endif; ?>

		<ul class="products product-category <?php echo ( "yes" == $carousel ) ? "owl-carousel" : ""; ?>" id="tpvc-carousel-<?php echo $carousel_id ?>">
		
		<?php
		foreach ( $product_categories as $category ) {

			wc_get_template( 'content-product_cat.php', array(
				'category' => $category
			) );

		} ?>

		</ul>

		<?php if( "yes" == $carousel ) : ?>
			<?php wp_enqueue_script( 'tokopress-js-owlcarousel' ); ?>
			<?php $js_code = "$('#tpvc-carousel-{$carousel_id}').owlCarousel({responsive:{ 0:{items:1}, 461:{items:2}, 992:{items:{$columns}} },loop: true, nav :{$paginate}, navText : ['<i class=\"ficon-angle-left\"></i>','<i class=\"ficon-angle-right\"></i>'], lazyLoad : true, autoPlay : true, dots: false });"; ?>
			<?php wc_enqueue_js( $js_code ); ?>
		<?php endif; ?>

	</div><?php
	}
	
	woocommerce_reset_loop();

	return ob_get_clean();
}

add_action( 'vc_before_init', 'pasar_vc_wc_categories' );
function pasar_vc_wc_categories() {

	if ( ! class_exists('woocommerce') )
		return;

	$args = array(
		'type' => 'post',
		'child_of' => 0,
		'parent' => '',
		'orderby' => 'name',
		'order' => 'ASC',
		'hide_empty' => false,
		'hierarchical' => 1,
		'exclude' => '',
		'include' => '',
		'number' => '',
		'taxonomy' => 'product_cat',
		'pad_counts' => false,

	);
	$categories = get_categories( $args );

	$product_categories_dropdown = array();
	pasar_vc_getCategoryChilds( 'id', 0, 0, $categories, 0, $product_categories_dropdown );

	$product_categories_dropdown_begin = array(
									__( '[Top Level Only]', 'tokopress' )	=> '0',
									__( '[All Categories]', 'tokopress' )	=> '',
								);
	$product_categories_dropdown = array_merge( $product_categories_dropdown_begin, $product_categories_dropdown );

	$params = array(
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Title', 'tokopress' ),
				'param_name'	=> 'title',
				'value'			=> __( 'Product Categories', 'tokopress' ),
			),
			array(
				'type'			=> 'dropdown',
				'heading'		=> __( 'Title Position', 'tokopress' ),
				'param_name'	=> 'title_position',
				'value'			=> array(
									__( 'Left', 'tokopress' )	=> 'left',
									__( 'Right', 'tokopress' )	=> 'right',
									__( 'Center', 'tokopress' )	=> 'center',
									__( 'Hide', 'tokopress' )	=> 'hide'
								),
				'std'			=> 'left'
			),
			array(
				'type' 			=> 'dropdown',
				'heading' 		=> __( 'Parent Category', 'tokopress' ),
				'value' 		=> $product_categories_dropdown,
				'param_name' 	=> 'parent',
				'description' 	=> __( 'Useful to show subcategories', 'tokopress' ),
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Numbers', 'tokopress' ),
				'description'	=> __( 'How many categories to show', 'tokopress' ),
				'param_name'	=> 'numbers',
				'value'			=> "8",
			),
			array(
				'type'			=> 'dropdown',
				'heading'		=> __( 'Columns', 'tokopress' ),
				'description'	=> __( 'How many columns per row', 'tokopress' ),
				'param_name'	=> 'columns',
				'value'			=> array(
									__( '1 Column', 'tokopress' )	=> '1',
									__( '2 Columns', 'tokopress' )	=> '2',
									__( '3 Columns', 'tokopress' )	=> '3',
									__( '4 Columns', 'tokopress' )	=> '4',
									__( '5 Columns', 'tokopress' )	=> '5'
								),
				'std'			=> '4'
			),
			array(
				'type'			=> 'dropdown',
				'heading'		=> __( 'Order By', 'tokopress' ),
				'param_name'	=> 'orderby',
				'value'			=> array(
									__( 'None', 'tokopress' )		=> 'none',
									__( 'Name', 'tokopress' )		=> 'name',
									__( 'Count', 'tokopress' )		=> 'count',
									__( 'Slug', 'tokopress' )		=> 'slug',
									__( 'ID', 'tokopress' )			=> 'id'
								),
				'std'			=> 'none'
			),
			array(
				'type'			=> 'dropdown',
				'heading'		=> __( 'Order', 'tokopress' ),
				'param_name'	=> 'order',
				'value'			=> array(
									__( 'Ascending', 'tokopress' )	=> 'ASC',
									__( 'Descending', 'tokopress' )	=> 'DESC'
								),
				'std'			=> 'ASC'
			),
			array(
				'type'			=> 'dropdown',
				'heading'		=> __( 'Carousel', 'tokopress' ),
				'param_name'	=> 'carousel',
				'value'			=> array(
									__( 'Yes', 'tokopress' )	=> 'yes',
									__( 'No', 'tokopress' )	=> 'no'
								),
				'std'			=> 'true'
			),
		);

	vc_map( array(
	   'name'				=> __( 'Pasar - WC Product Categories', 'tokopress' ),
	   'base'				=> 'pasar_wc_categories',
	   'class'				=> '',
	   'icon'				=> 'woocommerce_icon',
	   'category'			=> 'Pasar',
	   'admin_enqueue_js' 	=> '',
	   'admin_enqueue_css' 	=> '',
	   'params'				=> $params,
	   )
	);
}