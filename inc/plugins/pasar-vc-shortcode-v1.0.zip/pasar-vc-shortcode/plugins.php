<?php
/*
Plugin Name: Pasar VC & Shortcodes
Plugin URI: http://toko.press
Description: Visual Composer Addons and Shortcodes For Pasar WordPress Theme
Version: 1.0
Author: TokoPress
Author URI: http://toko.press/
License: GPL
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Load Languages
 **/
load_plugin_textdomain( 'tokopress', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );

define( "PASAR_PLUGIN_URI", plugins_url( '', __FILE__ ) );
define( "PASAR_VC_CSS_URI", PASAR_PLUGIN_URI . '/css/admin_vc_pasar.css' );

require_once( 'vc-elements/vc-banner.php' );
require_once( 'vc-elements/vc-brands.php' );
require_once( 'vc-elements/vc-promotions.php' );
require_once( 'vc-elements/vc-posts.php' );
require_once( 'vc-elements/vc-mailchimp.php' );

require_once( 'vc-elements/vc-wc-product-categories.php' );

require_once( 'vc-elements/vc-wc-products.php' );
require_once( 'vc-elements/vc-wc-products-onsale.php' );
require_once( 'vc-elements/vc-wc-products-bestselling.php' );
require_once( 'vc-elements/vc-wc-products-toprated.php' );
require_once( 'vc-elements/vc-wc-products-featured.php' );
require_once( 'vc-elements/vc-wc-products-incategory.php' );

require_once( 'Custom-Meta-Boxes/custom-meta-boxes.php' );
require_once( 'slider/slider.php' );

function pasar_vc_getCategoryChilds( $param = 'slug', $parent_id, $pos, $array, $level, &$dropdown ) {
	for ( $i = $pos; $i < count( $array ); $i ++ ) {
		if ( $array[ $i ]->category_parent == $parent_id ) {
			if ( $param == 'slug' ) {
				$data = array(
						str_repeat( "- ", $level ) . $array[ $i ]->name => $array[ $i ]->slug,
				);
			}
			else {
				$data = array(
						str_repeat( "- ", $level ) . $array[ $i ]->name => $array[ $i ]->term_id,
				);
			}
			$dropdown = array_merge( $dropdown, $data );
			pasar_vc_getCategoryChilds( $param, $array[ $i ]->term_id, $i, $array, $level + 1, $dropdown );
		}
	}
}
