<?php

// Register Custom Post Type
function pasar_slider_post_type() {

	$labels = array(
		'name'                => _x( 'Sliders', 'Post Type General Name', 'tokopress' ),
		'singular_name'       => _x( 'Slider', 'Post Type Singular Name', 'tokopress' ),
		'menu_name'           => __( 'Sliders', 'tokopress' ),
		'name_admin_bar'      => __( 'Sliders', 'tokopress' ),
		'parent_item_colon'   => __( 'Parent Item:', 'tokopress' ),
		'all_items'           => __( 'All Sliders', 'tokopress' ),
		'add_new_item'        => __( 'Add New Slider', 'tokopress' ),
		'add_new'             => __( 'Add New', 'tokopress' ),
		'new_item'            => __( 'New Slider', 'tokopress' ),
		'edit_item'           => __( 'Edit Slider', 'tokopress' ),
		'update_item'         => __( 'Update Slider', 'tokopress' ),
		'view_item'           => __( 'View Slider', 'tokopress' ),
		'search_items'        => __( 'Search Slider', 'tokopress' ),
		'not_found'           => __( 'Not found', 'tokopress' ),
		'not_found_in_trash'  => __( 'Not found in Trash', 'tokopress' ),
	);
	$args = array(
		'label'               => __( 'Simple Slider', 'tokopress' ),
		'description'         => __( 'Simple Slider', 'tokopress' ),
		'labels'              => $labels,
		'supports'            => array( 'title', ),
		'hierarchical'        => false,
		'public'              => true,
		'show_ui'             => true,
		'show_in_menu'        => true,
		'menu_position'       => 20,
		'menu_icon'           => 'dashicons-images-alt',
		'show_in_admin_bar'   => false,
		'show_in_nav_menus'   => false,
		'can_export'          => true,
		'has_archive'         => false,
		'exclude_from_search' => true,
		'publicly_queryable'  => true,
		'capability_type'     => 'page',
	);
	register_post_type( 'pasar_slider', $args );

}

// Hook into the 'init' action
add_action( 'init', 'pasar_slider_post_type', 0 );

add_filter('manage_edit-pasar_slider_columns', 'pasar_manage_edit_pasar_slider_columns');
function pasar_manage_edit_pasar_slider_columns( $columns ) {
	$columns['shortcode'] = __( 'Shortcode', 'tokopress' );
	return $columns;
}

add_action( 'manage_pasar_slider_posts_custom_column' , 'pasar_manage_pasar_slider_posts_custom_column', 10, 2 );
function pasar_manage_pasar_slider_posts_custom_column( $column, $post_id ) {
    if ($column == 'shortcode'){
        echo '<code>[pasar_slider id="'.get_the_ID().'"]</code>';
    }
}

function pasar_slider_metaboxes( array $meta_boxes ) {

	$slides = array(
		array( 'id' => 'desc',  'name' => __( 'Description', 'tokopress' ), 'type' => 'text', 'cols' => 6 ),
		array( 'id' => 'title',  'name' => __( 'Title', 'tokopress' ), 'type' => 'text', 'cols' => 6 ),
		array( 'id' => 'btn_text',  'name' => __( 'Button Text', 'tokopress' ), 'type' => 'text', 'cols' => 6 ),
		array( 'id' => 'btn_url',  'name' => __( 'Button URL', 'tokopress' ), 'type' => 'url', 'cols' => 6 ),
		array( 'id' => 'image', 'name' => __( 'Background Image', 'tokopress' ), 'type' => 'image', 'show_size' => false ),
	);

	$meta_boxes[] = array(
		'title' => __( 'Edit Slides', 'tokopress' ),
		'pages' => 'pasar_slider',
		'fields' => array(
			array(
				'id' => '_info',
				'name' => __( 'Shortcode', 'tokopress' ),
				'type' => 'slider_shortcode',
			),
			array(
				'id' => '_slides',
				'name' => '',
				'type' => 'group',
				'repeatable' => true,
				'sortable' => true,
				'fields' => $slides,
				'desc' => ''
			),
		)
	);

	return $meta_boxes;

}
add_filter( 'cmb_meta_boxes', 'pasar_slider_metaboxes' );

add_shortcode( 'pasar_slider', 'pasar_shortcode_slider' );
function pasar_shortcode_slider( $atts ) {
	extract( shortcode_atts( array(
		'id'	=> '',
		'slug'	=> '',
	), $atts ) );

	$slides = get_post_meta( $id, '_slides' );
	if ( empty( $slides ) )
		return;

	$output = '';

	$count = 0;
	foreach ( $slides as $slide ) {
		$output_slide = '';
		if ( trim( $slide['desc'] ) ) {
			$output_slide .= '<p class="tpvc-slide-desc">'.$slide['desc'].'</p>';
		}
		if ( trim( $slide['title'] ) ) {
			$output_slide .= '<h2 class="tpvc-slide-title">'.$slide['title'].'</h2>';
		}
		if ( trim( $slide['btn_text'] ) ) {
			$url = $slide['btn_url'] ? esc_url( $slide['btn_url'] ) : '#';
			$output_slide .= '<a class="tpvc-slide-button" href="'.$url.'">'.$slide['btn_text'].'</a>';
		}
		if ( $output_slide ) {
			$count++;
			$style = '';
			if ( $slide['image'] ) {
				$image = wp_get_attachment_url( $slide['image'] );
				if ( $image ) {
					$style = 'style="background-image:url('.$image.');background-size:cover;background-position:center right;background-repeat:no-repeat;" ';
				}
			}
			$output .= '<div class="tpvc-slide" '.$style.'><div class="tpvc-slide-inner"><div class="tpvc-slide-detail">'.$output_slide.'</div></div></div>';
		}
	}

	if ( $output ) {
		$class = $count > 1 ? 'tpvc-slider-active owl-carousel' : '';
		$output = '<div class="tpvc-slider-wrap"><div class="tpvc-slides '.$class.'">'.$output.'</div></div>';
		if ( $count > 1 ) {
			wp_enqueue_script( 'tokopress-js-owlcarousel' );
		}
	}

	return $output;
}

class Pasar_Slider_Shortcode_CMB_Field extends CMB_Field {

    public function html() {
        ?>
        <p>
            <?php echo '<code>[pasar_slider id="'.get_the_ID().'"]</code>'; ?>
        </p>
        <?php
    }

}

add_filter( 'cmb_field_types', function( $cmb_field_types ) {
    $cmb_field_types['slider_shortcode'] = 'Pasar_Slider_Shortcode_CMB_Field';
    return $cmb_field_types;
} );
